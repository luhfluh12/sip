<?php $this->widget('zii.widgets.jui.CJuiSortable', array(
//list of items
'items'=>$items,
// additional javascript options for the accordion plugin
'options'=>array(
    'connectWith'=>'.mergeSortableSchedule',
    'items'=>'.mergeSortableSchedule li',
    'placeholder'=>'ui-state-highlight',
    'forceHelperSize'=>'true',
    'revert'=>true,
    'distance'=>'3',
    'forcePlaceholderSize'=>'true',
    'scroll'=>'false',
    'tolerance'=>'pointer',
   
),
'htmlOptions'=>array(
    'class'=>'mergeSortableSchedule',
),
));
?>
