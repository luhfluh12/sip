<?php
$this->breadcrumbs=array(
	'Schoolyears'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Schoolyear', 'url'=>array('index')),
	array('label'=>'Manage Schoolyear', 'url'=>array('admin')),
);
?>

<h1>Create Schoolyear</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>