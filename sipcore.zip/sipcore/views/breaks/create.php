<?php
$this->breadcrumbs=array(
	'Breaks'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Breaks', 'url'=>array('index')),
	array('label'=>'Manage Breaks', 'url'=>array('admin')),
);
?>

<h1>Create Breaks</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>