<?php
$this->pageTitle=Yii::app()->name . ' - Site de dezvoltare';
$this->breadcrumbs=array(
	'',
);
$this->sip_title='Site de dezvoltare'; 
?>

<h1>Site-ul de dezvoltare a proiectului SIP</h1>

SIP (sistem de informare a părinților) este o aplicație web care trimite SMS-uri părinților a căror copii au o situație mai
neplăcută la școală.

<br /><br />

Pentru că această aplicație este îmbunătățită și optimizată în continuu, avem nevoie de acest site de dezvoltare. Aici vom
testa fiecare opțiune nouă, înainte de a o urca pe site-ul folosit de părinți și profesori, ca aceștia să nu întâmpine probleme.

<br /><br />

<strong>Acest site nu este dedicat utilizatorilor aplicației SIP, ci doar dezvoltatorilor
	și profesorilor care pot veni cu sugestii de îmbunătățire.</strong>