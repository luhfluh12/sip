<?php
$this->pageTitle='Despre Sip';
$this->breadcrumbs=array(
	'',
);
?>

<p>Acest program este realizat pentru informarea părinților despre situația școlară neplăcută a copiilor lor.</p>

