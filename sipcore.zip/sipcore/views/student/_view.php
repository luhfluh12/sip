<div class="view">
	<?php echo CHtml::link(CHtml::encode($data->name), array('student/view', 'id'=>$data->id)); ?>
</div>