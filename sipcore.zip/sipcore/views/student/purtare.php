
    Nota purtare: <?php echo $student->getPurtare(); ?>

