De la: <?php echo $model->name; ?> (<?php echo $model->email; ?>)
<?php echo $model->body; ?>