Aceasta este o copie a mesajului "<?php echo $model->subject; ?>", trimis din formularul de contact de pe site-ul SIPonline.

====
<?php echo $model->body; ?>

====

Vă vom răspunde cât mai rapid posibil. Acest e-mail a fost trimis automat.

Vă mulțumim,
http://siponline.ro
contact@siponline.ro
