<h1>Bună ziua, <strong><?php echo $model->email; ?></strong>,</h1>

Contul dvs. SIP (http://siponline.ro) a fost creat cu succes.<br/><br/>

SIP este o platformă care are ca scop ținerea la curent a părinților cu performanțele
copiilor la școală. <a href="http://siponline.ro/site/despre" target="_blank">Mai multe detalii</a>.

-- warning message --

-- activation steps --

E-mail: <strong><?php echo $model->email; ?></strong><br />
Telefon: <strong><?php echo $model->phone; ?></strong><br />
Cod de activare: <strong><?php echo $activation; ?></strong>
<br/><br/>

Vă rugăm să vă activați contul urmând legătura:
<a href="http://siponline.ro" target="_blank">http://siponline.ro</a>.
Pentru activare, veți fi rugat să setați o parolă pentru cont, să confirmați numărul de telefon și,
dacă doriți să primiți SMS-uri, să alegeți orele între care doriți să fiți informat.
<br /><br />
<br /><br />
Mulțumim pentru înțelegere,<br/>
<a href="http://siponline.ro">SIP online</a><br/>
<a href="mailto:contact@siponline.ro">contact@siponline.ro</a><br/>

<br/>
<em>Dacă nu doriți să folosiți acest program sau considerați că
    ați primit acest e-mail dintr-o greșeală, vă rugăm să ne anunțați
    folosind <a href='http://siponline.ro/index.php?r=site/contact' target='_blank'
    title="Contact SIPonline">formularul de contact</a> de pe site.</em>
