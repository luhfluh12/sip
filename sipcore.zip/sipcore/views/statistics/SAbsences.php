<div>
    <p>Absențe motivate: <strong><?php echo $stored['auth']; ?></strong></p>
    <p>Absențe nemotivate: <strong><?php echo $stored['unauth']; ?></strong></p>
</div>