<div class="view">
	<?php echo CHtml::link(CHtml::encode($data->name.' '.$data->city),
                array('view', 'id'=>$data->id),
                array('class'=>'title')); ?>
</div>