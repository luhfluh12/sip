<?php
$this->breadcrumbs=array(
	'Clase'=>array('index'),
);

$this->menu=array(
	array('label'=>'List Classes', 'url'=>array('index')),
	array('label'=>'Manage Classes', 'url'=>array('admin')),
);

$this->pageTitle='Adaugă o clasă';
?>

<?php echo $this->renderPartial('_form', array('class'=>$class,'account'=>$account)); ?>