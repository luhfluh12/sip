<div class="view">
    	<?php echo CHtml::link(CHtml::encode($data->grade.' '.$data->name),
                array('classes/view', 'id'=>$data->id),
                array('class'=>'title')); ?>
	<br /><?php echo CHtml::encode($data->profile); ?>
</div>