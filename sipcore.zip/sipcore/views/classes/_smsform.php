<h1>Trimite un SMS clasei</h1>

<p class="note">Fiecare părinte din această clasa vă primi acest mesaj SMS în următoarele 24 de ore.</p>


<?php $this->renderPartial('//sms/_form', array('model' => new Sms('manualSms'))); ?>
