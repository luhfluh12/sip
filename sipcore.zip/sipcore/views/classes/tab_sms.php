<h1>Trimite un mesaj SMS la toți elevii din clasă.</h1>

<?php
$this->renderPartial('//sms/_form');
