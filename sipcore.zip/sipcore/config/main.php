<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');
// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
    'basePath' => dirname(__FILE__) . DIRECTORY_SEPARATOR . '..',
    'name' => 'SIP',
    'language' => 'ro',
    // preloading 'log' component
    'preload' => array('log'),
    // autoloading model and component classes
    'import' => array(
        'application.models.*',
        'application.components.*',
        'application.components.SipWarnings.*',
        'application.components.SipStatistics.*',
        'ext.yii-mail.YiiMailMessage',
    ),
    'modules' => array(
        // uncomment the following to enable the Gii tool

        'gii' => array(
            'class' => 'system.gii.GiiModule',
            'password' => '123.4.2day',
            // If removed, Gii defaults to localhost only. Edit carefully to taste.
            'ipFilters' => array('127.0.0.1', '::1'),
        ),
        'help',
    ),
    // application components
    'components' => array(
        'user' => array(
            'class' => 'application.components.WebUser',
            'allowAutoLogin' => false,
        ),
        'db' => array(
            'connectionString' => 'mysql:host=localhost;dbname=school',
            'emulatePrepare' => true,
            'username' => 'root',
            'password' => 'fallen',
            'charset' => 'utf8',
        ),
        'authManager' => array(
            'class' => 'CDbAuthManager',
            'connectionID' => 'db',
        ),
        'errorHandler' => array(
            // use 'site/error' action to display errors
            'errorAction' => 'site/error',
        ),
        'log' => array(
            'class' => 'CLogRouter',
            'routes' => array(
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'error, warning',
                ),
            ),
        ),
        'mail' => array(
            'class' => 'ext.yii-mail.YiiMail',
            'transportType' => 'smtp',
            'viewPath' => 'application.views.mail',
            'logging' => true,
            'dryRun' => false,
            'transportOptions' => array(
                'host' => 'smtp.gmail.com',
                'username' => 'admin@siponline.ro',
                'password' => '3#Lives$Apart',
                'port' => '465',
                'encryption' => 'ssl',
            ),
        ),
        'widgetFactory' => array(
        /* 'widgets' => array(
          'CJuiAutoComplete' => array(
          'themeUrl' => 'css/jqueryui',
          'theme' => 'redmond',
          ),
          'CJuiDialog' => array(
          'themeUrl' => 'css/jqueryui',
          'theme' => 'redmond',
          ),
          'CJuiDatePicker' => array(
          'themeUrl' => 'css/jqueryui',
          'theme' => 'redmond',
          ),
          'CJuiTabs' => array(
          'themeUrl' => 'css/jqueryui',
          'theme' => 'redmond',
          ),
          'CJuiSortable' => array(
          'themeUrl' => 'css/jqueryui',
          'theme' => 'redmond',
          ),
          ), */
        ),
        'session' => array(
            'class' => 'CHttpSession',
        ),
    ),
    // application-level parameters that can be accessed
    // using Yii::app()->params['paramName']
    'params' => array(
        // this is used in contact page
        'adminEmail' => 'vlad.velici@gmail.com',
        'infoEmail' => 'contact@siponline.ro',
    ),
);